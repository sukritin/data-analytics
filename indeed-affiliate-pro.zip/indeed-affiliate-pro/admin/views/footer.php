<div class="uap-footer-wrap">	
	<div class="uap-additional-help">
		<div class="uap-footer-text"><strong>Ultimate Affiliate Pro v. <?php echo $plugin_vs; ?></strong> Wordpress Plugin by <a href="https://codecanyon.net/user/azzaroco/portfolio?ref=azzaroco" target="_blank">azzaroco</a></div>
			<a href="https://codecanyon.net/item/ultimate-affiliate-pro-wordpress-plugin/16527729?ref=azzaroco" target="_blank" title="Support us with 5-stars Rating for further development" class="button float_right uap-black-button" style="margin-right: 5px;"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i> 5-stars Rating </a>
			<a href="http://help.wpindeed.com/ultimate-affiliate-pro/" target="_blank" title="Knowledge Base" class="button float_right uap-green-button" style="margin-right: 5px;"><i class="fa fa-book"></i> Knowledge Base</a>
            <a href="https://www.youtube.com/playlist?list=PLmOiaKgLhsFl0M5nbPeLP1J6PbLvBkmeH" target="_blank" title="Video Tutorials" class="button float_right uap-red-button" style="margin-right: 5px;"><i class="fa fa-book"></i> Video Tutorials</a>
             <a href="https://store.wpindeed.com/addon/category/ultimate-affiliate-pro/" target="_blank" title="Video Tutorials" class="button float_right uap-blue-button" style="margin-right: 5px;"><i class="fa fa-book"></i> Extra AddOns</a>
			<a href="http://codecanyon.net/downloads/" target="_blank" title="Download Item" class="button float_right" style="margin-right: 5px;"><i class="fa fa-download"></i> Download</a>
	</div>
</div>	
