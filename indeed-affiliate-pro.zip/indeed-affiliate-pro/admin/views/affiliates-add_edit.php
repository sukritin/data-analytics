<div class="uap-wrapper">
	<div class="uap-stuffbox">
		<h3 class="uap-h3"><?php _e('Add/Update Affiliate user', 'uap');?></h3>
		<div class="inside uap-admin-edit">
        	<div class="uap-edit-profile-section-title">
        		<h3><?php echo __('Affiliate Profile details', 'uap'); ?></h3>
            	<p><?php echo __('Manage what fields are available for Admin setup from "Showcases->Register Form->Custom Fields" section', 'uap'); ?></p>
            </div>
			<?php echo $data['output'];?>
		</div>
	</div>
</div>


</div><!-- end of uap-dashboard-wrap -->	